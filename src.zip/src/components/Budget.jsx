// Imports
import React from "react";

// The Budget function 
function Budget() {
  return (
        <div className="section budget">
            <h3>Budget</h3>
            <div>+</div>
            <div>+</div>
            <div>+</div>
            <div>$</div>
        </div>
  );
}



// Export function
export default Budget;
