// Imports
import React from "react";



// The Header function returns the header of the webiste
function Header() {
  return (
    <div className="header">Home Page</div>
  );
}



// Export function
export default Header;
