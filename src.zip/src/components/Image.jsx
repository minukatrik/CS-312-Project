// Imports
import React from "react";



// The Image function ...
function Image() {
  return (
    <div className="section grid-container">
        <div className="grid-item">Image 1 <img src="placeholder.png" alt="Placeholder Image"></img></div>
        <div className="grid-item">image 2 <img src="placeholder.png" alt="Placeholder Image"></img></div>
        <div className="grid-item">image 3 <img src="placeholder.png" alt="Placeholder Image"></img></div>
        <div className="grid-item">image 4 <img src="placeholder.png" alt="Placeholder Image"></img></div>
        <div className="grid-item">image 5 <img src="placeholder.png" alt="Placeholder Image"></img></div>
        <div className="grid-item">image 6 <img src="placeholder.png" alt="Placeholder Image"></img></div>
    </div>
  );
}



// Export function
export default Image;
